--- Oreon ---

El archivo de entrada contiene varios casos de prueba. 
La primera línea indica cuántos casos de prueba habrá. 
Cada caso de prueba empieza con un entero n que indica la cantidad de ciudad amuralladas. 
Luego siguen n líneas con n entero cada una, cada uno indicando la cantidad de soldados que se necesitan para proteger el túnel que conecta dicha ciudad con las otras. 
Si uno de estos valores es 0 quiere decir que no existe túnel entre ese par de ciudades. 

Para cado caso de prueba debe escribirse una única línea con un entero, indicando la cantidad mínima de soldados que se necesitan para mantener las ciudades conectadas. 

(Se garantiza que en los casos de prueba no existen ciudades aisladas)

(Ver archivos oreon.in y oreon.out para un ejemplo, que representa la misma instancia que la imagen de las diapositivas)
